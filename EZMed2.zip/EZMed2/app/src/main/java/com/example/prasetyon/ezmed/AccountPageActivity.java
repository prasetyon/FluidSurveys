package com.example.prasetyon.ezmed;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class AccountPageActivity extends AppCompatActivity {

    ListView lvMedicine;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_page);
        setTitle("Account Page");

        lvMedicine = (ListView) findViewById(R.id.lvMedicine);

        setResource();
    }

    private void setResource()
    {
        ListAdapter adapter;
        ArrayList<String> fileName = new ArrayList<>();
        ArrayList<String> fileConsume = new ArrayList<>();
        ArrayList<String> fileAlarm1 = new ArrayList<>();
        ArrayList<String> fileAlarm2 = new ArrayList<>();
        ArrayList<String> fileAlarm3 = new ArrayList<>();
        ArrayList<String> fileStartDate = new ArrayList<>();
        ArrayList<String> fileEndDate = new ArrayList<>();

        fileName.add("Glukopack");
        fileName.add("Amoxicilin");
        fileName.add("Cefadroxil");
        fileName.add("Ester C");
        fileName.add("Vape");

        fileConsume.add("3");
        fileConsume.add("2");
        fileConsume.add("2");
        fileConsume.add("1");
        fileConsume.add("1");

        fileAlarm1.add("07:00");
        fileAlarm1.add("09:00");
        fileAlarm1.add("12:00");
        fileAlarm1.add("14:00");
        fileAlarm1.add("16:00");

        fileAlarm2.add("15:00");
        fileAlarm2.add("19:00");
        fileAlarm2.add("00:00");
        fileAlarm2.add("");
        fileAlarm2.add("");

        fileAlarm3.add("23:00");
        fileAlarm3.add("");
        fileAlarm3.add("");
        fileAlarm3.add("");
        fileAlarm3.add("");

        fileStartDate.add("23/12/2016");
        fileStartDate.add("22/12/2016");
        fileStartDate.add("23/12/2016");
        fileStartDate.add("-");
        fileStartDate.add("-");

        fileEndDate.add("26/12/2016");
        fileEndDate.add("27/12/2016");
        fileEndDate.add("31/12/2016");
        fileEndDate.add("-");
        fileEndDate.add("-");

        adapter = new Adapter(this, fileName, fileConsume, fileAlarm1, fileAlarm2, fileAlarm3, fileStartDate, fileEndDate);
        lvMedicine.setAdapter(adapter);
    }

    public class Adapter extends BaseAdapter {

        Context context;
        ArrayList<String> fileName;
        ArrayList<String> fileConsume;
        ArrayList<String> fileAlarm1;
        ArrayList<String> fileAlarm2;
        ArrayList<String> fileAlarm3;
        ArrayList<String> fileStartDate;
        ArrayList<String> fileEndDate;

        private LayoutInflater inflater=null;
        public Adapter(Context activity, ArrayList<String> fileName, ArrayList<String> fileConsume, ArrayList<String> fileAlarm1, ArrayList<String> fileAlarm2, ArrayList<String> fileAlarm3,
                       ArrayList<String> fileStartDate, ArrayList<String> fileEndDate) {
            // TODO Auto-generated constructor stub
            context=activity;
            this.fileName = fileName;
            this.fileConsume = fileConsume;
            this.fileAlarm1 = fileAlarm1;
            this.fileAlarm2 = fileAlarm2;
            this.fileAlarm3 = fileAlarm3;
            this.fileStartDate = fileStartDate;
            this.fileEndDate = fileEndDate;
            inflater = ( LayoutInflater )context.
                    getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        }
        @Override
        public int getCount() {
            // TODO Auto-generated method stub
            return fileEndDate.size();
        }

        @Override
        public Object getItem(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        @Override
        public long getItemId(int position) {
            // TODO Auto-generated method stub
            return position;
        }

        public class Holder
        {
            TextView tvNama, tvConsume, tvAlarm1, tvAlarm2, tvAlarm3, tvStartDate, tvEndDate;
        }

        @Override
        public View getView(final int position, View convertView, ViewGroup parent) {
            // TODO Auto-generated method stub
            Holder holder=new Holder();
            View rowView;
            rowView = inflater.inflate(R.layout.medicine_list, null);
            holder.tvNama = (TextView) rowView.findViewById(R.id.tvNama);
            holder.tvConsume = (TextView) rowView.findViewById(R.id.tvConsume);
            holder.tvAlarm1 = (TextView) rowView.findViewById(R.id.tvAlarm1);
            holder.tvAlarm2 = (TextView) rowView.findViewById(R.id.tvAlarm2);
            holder.tvAlarm3 = (TextView) rowView.findViewById(R.id.tvAlarm3);
            holder.tvStartDate = (TextView) rowView.findViewById(R.id.tvStartDate);
            holder.tvEndDate = (TextView) rowView.findViewById(R.id.tvEndDate);

            holder.tvNama.setText(fileName.get(position));
            holder.tvConsume.setText(fileConsume.get(position));
            holder.tvAlarm1.setText(fileAlarm1.get(position));
            holder.tvAlarm2.setText(fileAlarm2.get(position));
            holder.tvAlarm3.setText(fileAlarm3.get(position));
            holder.tvStartDate.setText(fileStartDate.get(position));
            holder.tvEndDate.setText(fileEndDate.get(position));

            return rowView;
        }
    }
}
